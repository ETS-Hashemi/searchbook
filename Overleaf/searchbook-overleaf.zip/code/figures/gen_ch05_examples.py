"""Generate the three example figures of Chapter 5 (TikZ, no figure env).

figures/ch05/idea.tex              A* from scratch vs D* Lite repair on a 14x8 grid
                                   (robot under way, obstacle appears ahead of it)
figures/ch05/lpastar-example.tex   g/rhs before, at, and after the change (5x3 grid)
figures/ch05/dstarlite-example.tex robot moves, obstacle appears, repair (7x5 grid)

All numbers come from ch05_dstar_lite.py, so they match the text.  The idea
figure uses a NumPy RNG with a fixed seed.  Run from Overleaf/:

    python3 code/figures/gen_ch05_examples.py
"""

import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
from ch05_dstar_lite import (INF, DStarLite, Grid, astar, dstar_lite_example,  # noqa: E402
                             lpastar_example, reachable)

FIGDIR = os.path.join(os.path.dirname(HERE), "..", "figures", "ch05")
SEED = 3


def fmt(x):
    return "\\infty" if x == INF else "%g" % x


def panel(lines, grid, xshift, fills=(), labels=None, paths=(), start=None, goal=None,
          robot=None, cross=None, title=None, font="\\tiny", frames=()):
    """One grid panel at xshift grid units.  fills/frames/paths: lists of (style, cells).

    frames are drawn on top of the obstacle fills, so a cell that is both blocked and
    highlighted stays visible."""
    w, h = grid.width, grid.height
    lines.append("\\begin{scope}[shift={(%g,0)}]" % xshift)
    for style, cells in fills:
        for (x, y) in cells:
            lines.append("\\fill[%s] (%d,%d) rectangle ++(1,1);" % (style, x, y))
    for (x, y) in sorted(grid.blocked):
        lines.append("\\fill[sbobstacle] (%d,%d) rectangle ++(1,1);" % (x, y))
    lines.append("\\draw[black!40,very thin] (0,0) grid (%d,%d);" % (w, h))
    for style, cells in frames:
        for (x, y) in cells:
            lines.append("\\draw[%s] (%d,%d) rectangle ++(1,1);" % (style, x, y))
    if cross is not None:
        x, y = cross
        lines.append("\\draw[white,line width=1.2pt] (%d.2,%d.2) -- ++(0.6,0.6) (%d.2,%d.8) -- ++(0.6,-0.6);"
                     % (x, y, x, y))
    for style, cells in paths:
        if cells:
            pts = " -- ".join("(%.1f,%.1f)" % (x + 0.5, y + 0.5) for x, y in cells)
            lines.append("\\draw[%s] %s;" % (style, pts))
    if robot is not None:
        lines.append("\\node[sbagentA,minimum size=7pt,inner sep=0pt] at (%.1f,%.1f) {};"
                     % (robot[0] + 0.5, robot[1] + 0.5))
    if labels:
        # A label under the robot disk or the obstacle cross gets a white plate so that
        # it stays readable; everything else is plain text.
        plated = {c for c in (robot, cross) if c is not None}
        for (x, y), text in sorted(labels.items()):
            style = "font=%s" % font
            if (x, y) in plated:
                style += ",fill=white,fill opacity=0.85,text opacity=1,inner sep=0.5pt"
            lines.append("\\node[%s] at (%.1f,%.1f) {%s};" % (style, x + 0.5, y + 0.5, text))
    if start is not None:
        lines.append("\\draw[sbStart,line width=1.2pt] (%d,%d) rectangle ++(1,1);" % start)
        lines.append("\\node[font=\\tiny,text=sbStart,anchor=north west,inner sep=1pt] at (%d,%d) {S};"
                     % (start[0], start[1] + 1))
    if goal is not None:
        lines.append("\\draw[sbGoal,line width=1.2pt] (%d,%d) rectangle ++(1,1);" % goal)
        lines.append("\\node[font=\\tiny,text=sbGoal,anchor=north west,inner sep=1pt] at (%d,%d) {T};"
                     % (goal[0], goal[1] + 1))
    if title:
        lines.append("\\node[sbannot,anchor=north,align=center] at (%.1f,-0.15) {%s};" % (w / 2.0, title))
    lines.append("\\end{scope}")


def write(name, lines):
    out = os.path.join(FIGDIR, name)
    with open(out, "w") as f:
        f.write("\n".join(lines) + "\n")
    print("wrote", os.path.normpath(out))


def idea_scenario(seed, w=14, h=8, density=0.22):
    """A random grid on which the robot walks a third of its planned path and
    then finds the cell two steps ahead of it blocked.  Returns what the
    figure and the chapter text need."""
    rng = np.random.default_rng(seed)
    start, goal = (0, h // 2), (w - 1, h // 2)
    while True:
        blocked = {(int(x), int(y)) for x in range(w) for y in range(h)
                   if rng.random() < density and (x, y) not in (start, goal)}
        grid = Grid(w, h, blocked)
        if not reachable(grid, start, goal):
            continue
        d = DStarLite(grid, start, goal)
        n_init = d.compute_shortest_path()
        path0 = d.path()
        if len(path0) - 1 < w + 1:          # want a path with at least one detour
            continue
        for _ in range(len(path0) // 3):
            d.move()
        robot = d.start
        obstacle = d.path()[2]
        grid.set_blocked(obstacle)
        if reachable(grid, robot, goal):
            break
    d.events = []
    n_rep = d.notify_changed_cells([obstacle])
    expanded = {ev[1] for ev in d.events if ev[0] == "pop"}
    a = astar(grid, robot, goal)
    assert a.cost == d.g_of(robot)
    return {"grid": grid, "start": start, "goal": goal, "robot": robot,
            "obstacle": obstacle, "path0": path0, "path1": d.path(),
            "expanded": expanded, "n_init": n_init, "n_rep": n_rep, "astar": a,
            "k_m": d.k_m}


def idea_figure():
    r = idea_scenario(SEED)
    grid, a = r["grid"], r["astar"]
    lines = ["% Generated by code/figures/gen_ch05_examples.py -- do not edit",
             "\\begin{tikzpicture}[scale=0.5]"]
    panel(lines, grid, 0.0, fills=[("sbclosed", a.closed)],
          paths=[("sbpath,opacity=0.35", r["path0"]), ("sbpath", a.path)],
          start=r["start"], goal=r["goal"], robot=r["robot"], cross=r["obstacle"],
          title="\\astar from scratch: %d expansions" % a.expansions)
    assert r["obstacle"] in set(r["expanded"]), "blocked cell should be an expansion"
    panel(lines, grid, grid.width + 1.5, fills=[("sbOrange!35", r["expanded"])],
          frames=[("sbOrange,line width=1.2pt", [r["obstacle"]])],
          paths=[("sbpath,opacity=0.35", r["path0"]), ("sbpathalt", r["path1"])],
          start=r["start"], goal=r["goal"], robot=r["robot"], cross=r["obstacle"],
          title="\\dstarlite repair: %d expansions" % r["n_rep"])
    lines.append("\\end{tikzpicture}")
    write("idea.tex", lines)
    print("idea figure (seed %d): robot at %s, obstacle at %s, initial search %d, "
          "repair %d, A* from scratch %d, costs %d -> %d, k_m %g"
          % (SEED, r["robot"], r["obstacle"], r["n_init"], r["n_rep"], a.expansions,
             len(r["path0"]) - 1, len(r["path1"]) - 1, r["k_m"]))
    return r


def lpa_labels(state):
    return {s: "$%s/%s$" % (fmt(state["g"][s]), fmt(state["rhs"][s]))
            for s in state["g"] if not (state["g"][s] == INF and state["rhs"][s] == INF)}


def lpa_fills(state):
    consistent = [s for s in state["g"] if state["g"][s] == state["rhs"][s] and state["g"][s] < INF]
    under = [s for s in state["queue"] if state["g"][s] < state["rhs"][s]]
    over = [s for s in state["queue"] if state["g"][s] > state["rhs"][s]]
    return [("sbclosed", consistent), ("sbopen", over), ("sbOrange!45", under)]


def lpastar_figure():
    r = lpastar_example()
    grid = r["grid"]
    clean = Grid(grid.width, grid.height, ())
    lines = ["% Generated by code/figures/gen_ch05_examples.py -- do not edit",
             "\\begin{tikzpicture}[scale=0.88]"]
    e = {"start": (0, 1), "goal": (4, 1)}
    panel(lines, clean, 0.0, fills=lpa_fills(r["state_first"]), labels=lpa_labels(r["state_first"]),
          paths=[("sbpath,opacity=0.5", r["path_first"])], start=e["start"], goal=e["goal"],
          title="after the first search", font="\\scriptsize")
    panel(lines, grid, 6.0, fills=lpa_fills(r["state_change"]), labels=lpa_labels(r["state_change"]),
          start=e["start"], goal=e["goal"], title="$(3,1)$ blocked, before the repair",
          font="\\scriptsize")
    panel(lines, grid, 12.0, fills=lpa_fills(r["state_repair"]), labels=lpa_labels(r["state_repair"]),
          paths=[("sbpath,opacity=0.5", r["path_repair"])], start=e["start"], goal=e["goal"],
          title="after the repair", font="\\scriptsize")
    lines.append("\\end{tikzpicture}")
    write("lpastar-example.tex", lines)


def dsl_labels(state, extra=()):
    """g-values of the expanded cells, written g/rhs where the cell is inconsistent.

    Cells that were only ever queued keep g = INF and stay blank, as before; the
    second number is what shows why the highlighted cells are inconsistent."""
    out = {}
    for s in state["g"]:
        g, rhs = state["g"][s], state["rhs"][s]
        if g == INF and s not in extra:
            continue
        if g == INF and rhs == INF:
            continue
        out[s] = "$%s$" % fmt(g) if g == rhs else "$%s/%s$" % (fmt(g), fmt(rhs))
    return out


def dstarlite_figure():
    r = dstar_lite_example()
    grid = r["grid"]
    # the vertices UpdateVertex actually changed when (3,3) was blocked
    changed = {ev[1] for ev in r["change_events"] if ev[2] != ev[3] or ev[4] != ev[5]}
    before = Grid(grid.width, grid.height, set(grid.blocked) - {(3, 3)})
    start, goal = (0, 3), (6, 2)
    lines = ["% Generated by code/figures/gen_ch05_examples.py -- do not edit",
             "\\begin{tikzpicture}[scale=0.62]"]
    panel(lines, before, 0.0, fills=[("sbclosed", [s for s in r["state0"]["g"] if r["state0"]["g"][s] < INF])],
          labels=dsl_labels(r["state0"]), paths=[("sbpath", r["path0"])],
          start=start, goal=goal, robot=start, title="initial plan, cost %d" % (len(r["path0"]) - 1))
    panel(lines, grid, 8.0, fills=[("sbOrange!45", r["inconsistent"])],
          labels=dsl_labels(r["state_change"], extra=changed), paths=[("sbpathalt", r["path0"][2:])],
          start=start, goal=goal, robot=r["robot_after_change"], cross=(3, 3),
          title="robot at $(2,3)$, $(3,3)$ blocked")
    panel(lines, grid, 16.0, fills=[("sbclosed", r["expanded"])],
          labels=dsl_labels(r["state1"]),
          paths=[("sbOrange,line width=1.6pt,opacity=0.6", r["route"][:3]), ("sbpath", r["path1"])],
          start=start, goal=goal, robot=r["robot_after_change"],
          title="after the repair, cost %d" % (len(r["path1"]) - 1))
    lines.append("\\end{tikzpicture}")
    write("dstarlite-example.tex", lines)


def main():
    idea_figure()
    lpastar_figure()
    dstarlite_figure()


if __name__ == "__main__":
    main()
